<?php if ( $wp_query->max_num_pages > 1 ) {

		echo sohohotel_pagination( $wp_query );
	
} ?>